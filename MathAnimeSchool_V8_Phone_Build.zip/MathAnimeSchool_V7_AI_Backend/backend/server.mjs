import "dotenv/config";
import express from "express";
import cors from "cors";
import multer from "multer";
import OpenAI from "openai";

const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024 }
});

app.use(cors());
app.get("/health", (_, res) => res.json({ ok: true, service: "MathAnime AI" }));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.post("/solve", upload.single("image"), async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: "OPENAI_API_KEY is not configured on the server." });
    }
    if (!req.file) {
      return res.status(400).json({ error: "No image uploaded." });
    }

    const mime = req.file.mimetype || "image/jpeg";
    const dataUrl = `data:${mime};base64,${req.file.buffer.toString("base64")}`;

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      input: [{
        role: "user",
        content: [
          {
            type: "input_text",
            text: `You are a patient school mathematics teacher.
Read the math problem in the image. Answer in simple Bengali unless the image clearly indicates another language.
Do NOT just give the final answer.
Return:
1) Detected question
2) What the student needs to know
3) Step-by-step explanation
4) A short Anime teacher dialogue
5) One similar practice problem
6) A small hint for the practice problem
If the image is unclear, say exactly what part is unclear and ask for a clearer photo.
Keep the explanation age-appropriate and educational.`
          },
          { type: "input_image", image_url: dataUrl }
        ]
      }]
    });

    res.json({ lesson: response.output_text });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "AI processing failed." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`MathAnime AI backend listening on ${port}`));
