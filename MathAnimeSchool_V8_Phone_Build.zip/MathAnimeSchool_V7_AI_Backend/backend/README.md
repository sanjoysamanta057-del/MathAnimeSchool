# MathAnime AI Backend

This server receives a math-question image and sends it to the OpenAI Responses API using an image input. The API key stays on the server.

## Setup

1. Install Node.js.
2. In this folder run:
   npm install
3. Copy `.env.example` to `.env`.
4. Put your server-side API key in `OPENAI_API_KEY`.
5. Run:
   npm start

Health check:
GET /health

AI endpoint:
POST /solve
multipart/form-data field: image

## Security

Do not put the OpenAI key in the Android project. OpenAI recommends routing mobile-app requests through your own backend and keeping keys in environment variables.

Before production, add authentication, rate limits, request-size controls, logging without sensitive student data, HTTPS, moderation/safety controls, and appropriate child/privacy compliance.
