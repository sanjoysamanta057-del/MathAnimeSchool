# MathAnime School V7 — Real AI Backend Starter

V7 adds a real server-side AI integration path.

## Flow

Android app
  -> HTTPS backend `/solve`
  -> OpenAI Responses API with image input
  -> guided math lesson text
  -> Android Anime Teacher screen

The Android app contains only a placeholder backend URL. It does NOT contain an OpenAI API key.

## Important

You must deploy the backend to a server with HTTPS before a public app release. Replace `YOUR-BACKEND-DOMAIN.example` in `MainActivity.kt` with your real HTTPS backend URL.

For local Android testing, a real phone generally cannot use `localhost` to mean your computer; use your computer's LAN IP while both devices are on the same network.

The backend uses a vision-capable OpenAI model and can read image inputs through the Responses API. See the official OpenAI developer documentation.

Do not upload or publish `.env` or any API key.

## Still required for a production school app

- Authentication and school accounts
- Database and curriculum management
- Board/textbook rights/licensing
- HTTPS deployment and domain
- Rate limiting and abuse prevention
- Student/parent/school privacy and consent
- Moderation and age-appropriate safeguards
- Real Anime animation/voice
- Live class infrastructure
- Adaptive games
- Error monitoring and QA
- Signed AAB and Play Console setup
