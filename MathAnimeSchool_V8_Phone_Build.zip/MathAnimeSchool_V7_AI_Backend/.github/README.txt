Cloud build workflow is in .github/workflows/android-build.yml
