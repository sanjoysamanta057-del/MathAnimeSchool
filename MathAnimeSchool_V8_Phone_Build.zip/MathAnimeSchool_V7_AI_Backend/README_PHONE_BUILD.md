# MathAnime School V8 — Phone/Cloud Build

This version is prepared so you can build the Android project from GitHub Actions without installing Android Studio on your phone.

## What was improved
- Cloud build workflow: `.github/workflows/android-build.yml`
- Camera capture now saves the image and uploads it through FileProvider.
- Backend URL can be supplied at build time with `-PMATHANIME_BACKEND_URL=...`.
- API keys are still kept only on the backend.

## Phone workflow
1. Create a GitHub account.
2. Create a new repository.
3. Upload all files from this project to the repository.
4. Open **Actions** → **Android Cloud Build** → **Run workflow**.
5. When it finishes, open the workflow run and download the APK artifact.
6. For the AI to work, deploy the `backend/` folder separately and set the real HTTPS `/solve` URL before a production build.

## Important
The generated release AAB from this starter is not a Play Store-ready signed bundle yet. Production signing, app identity, privacy/child-safety work, backend deployment, authentication, database, curriculum licensing, and testing still need to be completed.

Never put an OpenAI API key in the Android app or send it to anyone.
