package com.mathanime.school

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    // For local testing use your computer's LAN IP, e.g. http://192.168.1.10:3000
    // For production replace with your HTTPS backend URL.
    // Set -PMATHANIME_BACKEND_URL when building, or keep the placeholder for demo mode.
    private val BACKEND = BuildConfig.MATHANIME_BACKEND_URL
    private var cameraUri: Uri? = null

    private fun openCamera() {
        val dir = File(cacheDir, "camera").apply { mkdirs() }
        val photo = File(dir, "question_${System.currentTimeMillis()}.jpg")
        cameraUri = FileProvider.getUriForFile(this, "${BuildConfig.APPLICATION_ID}.fileprovider", photo)
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(MediaStore.EXTRA_OUTPUT, cameraUri)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivityForResult(intent, 101)
    }

    private fun btn(s:String,f:()->Unit)=Button(this).apply{
        text=s;textSize=16f;setOnClickListener{f()}
        layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,6,0,6)}
    }
    private fun base(title:String)=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL;setPadding(26,22,26,22)
        addView(TextView(this@MainActivity).apply{
            text=title;textSize=27f;typeface=Typeface.DEFAULT_BOLD
            setPadding(0,0,0,16)
        })
    }
    private fun page(title:String,body:String){
        val l=base(title)
        l.addView(TextView(this).apply{text=body;textSize=17f})
        l.addView(btn("← Home"){home()});setContentView(l)
    }

    private fun scan(){
        val l=base("📸 Scan Math Question")
        l.addView(TextView(this).apply{
            text="Take a photo or choose an image. The secure backend will send the image to the AI vision model for question recognition and a guided lesson."
            textSize=17f
        })
        l.addView(btn("📷 Take Photo"){
            if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)
                ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.CAMERA),101)
            else openCamera()
        })
        l.addView(btn("🖼️ Choose From Gallery"){
            val i=Intent(Intent.ACTION_OPEN_DOCUMENT);i.type="image/*";i.addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(i,102)
        })
        l.addView(btn("🧪 Demo Without Internet"){demoLesson()})
        l.addView(btn("← Home"){home()})
        setContentView(l)
    }

    private fun uploadImage(uri:Uri){
        val progress=ProgressBar(this)
        val root=base("🤖 AI is reading the question…")
        root.addView(progress)
        root.addView(TextView(this).apply{text="Please wait.";textSize=17f})
        setContentView(root)

        thread {
            try {
                val input=contentResolver.openInputStream(uri) ?: throw Exception("Could not open image")
                val bytes=input.readBytes(); input.close()
                val boundary="----MathAnime"+UUID.randomUUID()
                val conn=URL(BACKEND).openConnection() as HttpURLConnection
                conn.requestMethod="POST";conn.doOutput=true
                conn.setRequestProperty("Content-Type","multipart/form-data; boundary=$boundary")
                conn.connectTimeout=20000;conn.readTimeout=60000
                DataOutputStream(conn.outputStream).use { out ->
                    out.writeBytes("--$boundary\r\n")
                    out.writeBytes("Content-Disposition: form-data; name=\"image\"; filename=\"question.jpg\"\r\n")
                    out.writeBytes("Content-Type: image/jpeg\r\n\r\n")
                    out.write(bytes);out.writeBytes("\r\n--$boundary--\r\n")
                }
                val response=conn.inputStream.bufferedReader().readText()
                runOnUiThread {
                    // Backend returns JSON with "lesson"; a simple parser keeps this starter dependency-free.
                    val lesson=Regex("\"lesson\"\\s*:\\s*\"(.*?)\"\\s*}").find(response)?.groupValues?.get(1)
                        ?.replace("\\n","\n")?.replace("\\\"","\"")
                        ?: response
                    page("🎭 AI + Anime Lesson",lesson)
                }
            } catch(e:Exception){
                runOnUiThread {
                    page("Connection Error","The AI server could not be reached.\n\nCheck your backend URL, internet connection and server logs.\n\nFor safety, no API key is stored in this Android app.")
                }
            }
        }
    }

    private fun demoLesson(){
        page("🎭 Demo AI + Anime Lesson",
            "Detected question: 2x + 6 = 14\n\n" +
            "Anime Teacher: “Let's solve it together.”\n\n" +
            "Step 1: Remove 6 from both sides.\n2x = 8\n\n" +
            "Step 2: Divide both sides by 2.\nx = 4\n\n" +
            "Practice: 3x + 5 = 20")
    }

    private fun home(){
        val l=base("🧮 MathAnime School V7")
        l.addView(TextView(this).apply{text="Real AI backend integration starter";textSize=16f})
        l.addView(btn("📸 Scan & Ask AI"){scan()})
        l.addView(btn("📚 Board / Class / Chapter"){
            page("📚 Course","Board → Class → Chapter → Exercise\n\nProduction curriculum data can be loaded from the school backend.")
        })
        l.addView(btn("🎭 Anime Teacher"){
            page("🎭 Anime Teacher","The AI backend now produces the lesson text. The next layer can turn that lesson into animation and voice.")
        })
        l.addView(btn("👨‍🏫 Teacher / School"){
            page("👨‍🏫 School","Teacher accounts, classes, students, tests and question-paper generation will use the secure backend.")
        })
        l.addView(btn("🎮 Games"){
            page("🎮 Games","Adaptive maths games will use the student's class and learning progress.")
        })
        setContentView(l)
    }

    override fun onActivityResult(r:Int,c:Int,d:Intent?){
        super.onActivityResult(r,c,d)
        if(c != Activity.RESULT_OK) return

        if(r == 101) {
            val uri = cameraUri
            if(uri != null) uploadImage(uri)
            else page("Camera Error","The captured image could not be found. Please try again.")
        } else if(r == 102 && d?.data != null) {
            uploadImage(d.data!!)
        }
    }
    override fun onCreate(b:Bundle?){super.onCreate(b);home()}
}
