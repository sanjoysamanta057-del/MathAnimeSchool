plugins {
 id("com.android.application")
 id("org.jetbrains.kotlin.android")
}
android {
    buildFeatures { buildConfig = true }
 namespace="com.mathanime.school"
 compileSdk=35
 defaultConfig {
        buildConfigField("String", "MATHANIME_BACKEND_URL", "\"${project.findProperty("MATHANIME_BACKEND_URL") ?: "https://YOUR-BACKEND-DOMAIN.example/solve"}\"")
  applicationId="com.mathanime.school"
  minSdk=23
  targetSdk=35
  versionCode=7
  versionName="7.0"
 }
}
dependencies {
 implementation("androidx.core:core-ktx:1.15.0")
 implementation("androidx.appcompat:appcompat:1.7.0")
 implementation("com.google.android.material:material:1.12.0")
}